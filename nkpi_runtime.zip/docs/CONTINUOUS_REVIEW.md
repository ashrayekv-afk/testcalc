# Continuous bilateral review and C reconciliation — 9.1.4

## Source of truth

`result.case.first.C` or `result.case.latest.C` is used only for the exact requested eye,
verified case and compatible mode/visit. The ordinary scalar C input range check in
this viewer is 100–2000 µm. It excludes stage numbers and does not replace the existing
calculator validation. This value is labeled Verified C, meaning user-confirmed input.

The original spatial minimum is obtained from `NKPIIntegratedMeasurements.findThinnest`
BEFORE any visual completion. It is never recomputed over the filled surface. Its
reported delta is original reconstructed minimum minus verified C. This delta is a
reconciliation aid, not an accuracy certificate, repeatability threshold or diagnosis.

C alone cannot specify an x/y coordinate. A verified baseline `case.landmarks.thin_x`
and `thin_y` may be used because that input case represents one scan. Unscoped landmarks
are never reused on a longitudinal pair. A specifically associated `thinnest_point`
object may be used by the viewer if it declares `verified: true`, the same eye and
visit, `coordinate_system: viewer_xy_mm`, and finite in-field `x_mm`, `y_mm`. The current
upstream parser need not supply that object; this does not claim automatic XY extraction
for every report layout. Otherwise use the original grid minimum and label it as such.

At a supplied thinnest coordinate, the scalar C can be displayed as Verified C at
supplied XY. The locally reconstructed thickness is separately shown, or marked not
supported. The fitted geometry is not forced through a scalar C constraint whose
coordinate/reference cannot be independently established.

## Completion algorithm and limits

`continuous_review.js` creates independent display arrays. It does not write to the
source grids, original vertices, calculated report values, input case, model coefficients
or the retained selected minimum. Front heights are represented as departures from the
existing reference sphere. Missing departures are initialized with nearest known values,
then discrete harmonic completion is run with existing finite anchors fixed. The filled
map field uses the same fixed-anchor approach. Maximum-principle tests check that it
neither moves anchors nor introduces values beyond their range.

This is not tissue modelling or a validated inverse reconstruction. It may smooth or
miss a cone hidden in an absent region. Local consistency does not establish anatomical
accuracy. The algorithm is a bounded visual completion, including broad missing areas,
and is explicitly labeled as such. The surrounding unmeasured cornea is smoothly blended
to reference anatomy. Without enough source geometry the model is labeled reference.
An entirely absent map has no invented map layer.

Native original front/back coordinate arrays are kept unchanged. Render vertices sample
the original/complete fields into a polar front mesh; an inner mesh and outer rim make a
closed display shell. This visual resampling is not a replacement data export and is not
a guarantee of interpolation accuracy between device points. Independently supplied
posterior coordinates are used where valid; otherwise the inner boundary is derived from
thickness and the front normal. Where no thickness data exist it is a reference boundary
and is labeled as such. The distance between native paired surfaces is not relabeled as
device pachymetry. The display does not simulate patient vision or corneal biomechanics.

For numerical point readouts, direct imported/decoded map samples and the pre-existing
bounded local map estimator are consulted. Broad harmonic fill does not supply a number.
C remains separately visible. Thus a continuous colored region can legitimately have an
unavailable numeric reading. Fine hatching and the support overlay identify completion.
Colors in such areas are illustrative, not recovered device measurements.

## Display and source association

The existing report-to-verified-case association in the calculator is retained. New
patients, changed sources, edited input values and removed eyes clear stale associations.
No cross-eye or cross-visit fallbacks are added. Initial visit prefers latest where
available; explicit Baseline/Latest controls remain. If the selected eye has no report
for that visit, it has no patient-specific geometry or fabricated readings.

OD and OS use equal physical axes and a common camera scale. Compatible map definitions
share color bounds; incompatible maps retain their own scale. The front map projection is
separate from 3D position. Curvature remains an attribute, not an extra deformation.
Natural whole surface uses lighting and transparency. Maps have undiluted measurement
colors. Rotation, zoom and slice direction are linked, while selection is per-eye.

Slice through point draws a defined line and a profile using the same geometry, with
no tissue wedge. It is an inspection view, not a tomographic scan or independent thickness
measurement. Unsupported geometry segments are dashed amber. Changing the field, camera,
or slice angle never changes the source coordinates or verified C.

Original report uses linked pages that are already present in the browser. It adds no
external image upload or texture service. Combined PNG export includes C, original grid
minimum, coordinates, provenance, shared legend and completion warning. These exports may
contain health information and must be handled accordingly; the software distribution
contains no reports or prepared patient examples.

## What has not been established

This release does not validate reconstruction error against native Pentacam coordinates,
measurement repeatability, clinical decision accuracy, automated C/XY OCR accuracy on a
new scan, or Streamlit Cloud deployment. See V914_VERIFICATION.md. Native-format import
still requires the documented numerical schema; a clinic-specific adapter cannot be
claimed validated from report JPEGs alone.
