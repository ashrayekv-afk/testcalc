'use strict';
// Synthetic source pixels and deterministic OCR responses test the coordinate
// and validation contract. These are not patient data or end-to-end OCR tests.
const assert=require('node:assert/strict');
const {test}=require('node:test');
const I=require('../components/image_regions.js');

function fixture(){
 const width=1200,height=920,im={width,height,data:new Uint8ClampedArray(width*height*4).fill(255)},c={cx:490,cy:264,r:100};
 const colors=[{rgb:[70,140,220],value:-12,lo:-14,hi:-10,step:4},{rgb:[220,170,80],value:18,lo:16,hi:20,step:4}];
 for(let y=164;y<=364;y++)for(let x=390;x<=590;x++){
  if(Math.hypot(x-c.cx,y-c.cy)>99)continue;
  const col=x<520?colors[0].rgb:colors[1].rgb,k=(y*width+x)*4;
  im.data.set([...col,255],k);
 }
 return {im,c,colors};
}
function central(values=0){return Array.from({length:41},(_,j)=>Array.from({length:41},(_,i)=>Math.hypot(i-20,j-20)<=20?{value:values,lo:values-2,hi:values+2}:null));}
function shape(){return {schema:'nkpi-image-shape-1',source:'report_elevation_estimate',reference:'centered_untilted_float_bfs',bfs_radius_mm:7.8,fit_diameter_mm:8,diameter_mm:9,extent:2/3,elevation_um:central(),legend_step_um:4};}
function map(){return {schema:'nkpi-report-image-map-1',id:'anterior',unit:'D',map_type:'axial',source:'report_color_estimate',diameter_mm:9,extent:2/3,registration:'printed_plot_circle',grid:central(45)};}
function posterior(){return {schema:'nkpi-image-elevation-map-1',surface:'posterior',source:'report_elevation_estimate',reference:'independent_posterior_float_bfs',unit:'um',bfs_radius_mm:6.5,fit_diameter_mm:8,diameter_mm:9,extent:2/3,elevation_um:central(-12)};}

test('Central regional sampler remains exactly the previous 41x41 pixel calculation',()=>{
 const {im,c,colors}=fixture(),old=[];
 for(let j=0;j<41;j++){const row=[];for(let i=0;i<41;i++){const x=(i/40*2-1)*2/3,y=(j/40*2-1)*2/3;row.push(Math.hypot(x,y)>2/3?null:I.sampleColor(im,c,colors,c.cx+x*c.r,c.cy+y*c.r));}old.push(row);}
 assert.deepEqual(I.grid(im,c,colors),old);
});

test('Full display samples original outer pixels, not a stretched central map',()=>{
 const {im,c,colors}=fixture(),d=I.displayGrid(im,c,colors,9),g=I.grid(im,c,colors);
 assert.equal(d.grid.length,61);assert.equal(g.length,41);assert.equal(d.diameter_mm*d.extent,9);
 assert.equal(g[20][30].value,18); // Original x=+1.5mm.
 assert.equal(d.grid[30][40].value,18); // Same physical point, independent source sample.
 assert.equal(d.grid[30][54].value,18); // x=+3.6mm exists only in the full grid.
 assert.equal(d.grid[0][0],null);assert.equal(d.grid[30][0],null); // Outside/white print edge.
 I.validateDisplayGrid(d,{diameter_mm:9});
 assert.equal(I.grid(im,c,colors)[20][30].value,g[20][30].value);
});

test('Full display rejects altered diameter, extent, shape, coverage and fabricated outer samples',()=>{
 const {im,c,colors}=fixture(),d=I.displayGrid(im,c,colors,9);
 for(const edit of [x=>x.diameter_mm=12,x=>x.extent=2/3,x=>x.grid.pop(),x=>x.grid[10].pop(),x=>x.coverage=.01,x=>x.grid[0][0]={value:10,lo:9,hi:11},x=>x.grid[30][30].value=Infinity,x=>x.grid[30][30].lo=999,x=>x.grid[30][30].sampling='invented']){
  const bad=structuredClone(d);edit(bad);assert.throws(()=>I.validateDisplayGrid(bad,{diameter_mm:9}));
 }
});

test('Optional full map fields preserve the source central grids and remain backward compatible',()=>{
 const {im,c,colors}=fixture(),m=map(),s=shape(),p=posterior();
 const before=[JSON.stringify(m.grid),JSON.stringify(s.elevation_um),JSON.stringify(p.elevation_um)];
 I.validateMap(m);I.validateShape(s);I.validatePosteriorElevation(p);
 m.full_display=I.displayGrid(im,c,colors,9);
 s.full_display=I.displayGrid(im,c,colors,9,'elevation_um');
 p.full_display=I.displayGrid(im,c,colors,9,'elevation_um');s.posterior_elevation=p;
 I.validateMap(m);I.validateShape(s);
 assert.deepEqual([JSON.stringify(m.grid),JSON.stringify(s.elevation_um),JSON.stringify(p.elevation_um)],before);
 const invalid=structuredClone(s);invalid.posterior_elevation.reference='centered_untilted_float_bfs';assert.throws(()=>I.validateShape(invalid));
});

test('Posterior map keeps signed elevations and its independent reference metadata',()=>{
 const p=posterior();assert.equal(I.validatePosteriorElevation(p).elevation_um[20][20].value,-12);
 for(const edit of [x=>x.surface='anterior',x=>x.unit='mm',x=>x.reference='registered_to_front',x=>x.bfs_radius_mm=100,x=>x.elevation_um=central(3000),x=>x.elevation_um=central().map(row=>row.map(()=>null))]){
  const bad=structuredClone(p);edit(bad);assert.throws(()=>I.validatePosteriorElevation(bad));
 }
});

function fakeDocument(){return {createElement(){const canvas={width:0,height:0,calls:[]};canvas.getContext=()=>({drawImage(...args){canvas.calls.push(args);},fillRect(){}});return canvas;}};}
async function readBack(overrides={}){
 const {im,c,colors}=fixture(),frame={top:100,scale:1,cx:1018},regions=[{role:'elevation_front',cx:215/1200,cy:264/920,rx:100/1200,identity:'report-layout'},{role:'elevation_back',cx:c.cx/1200,cy:c.cy/920,rx:100/1200,identity:'report-layout'}];
 if(overrides.region)overrides.region(regions);
 const captions=[],read=async(canvas,options)=>{
  const crop=canvas.calls[0]?.[0]?.calls?.[0];if(crop)captions.push(crop.slice(1,5));
  if(options.whitelist==='0123456789.')return {text:overrides.radius||'6.50'};
  if(options.whitelist==='0123456789.m')return {text:overrides.diameter||'9mm'};
  return {text:overrides.caption||'BFS (B) Float R=6.50 Dia=8.00'};
 };
 const result=await I.readPosteriorElevation({width:1200,height:920},im,regions,frame,read,colors,4);
 return {...result,captions};
}
test('Posterior reader uses the identified back circle, own BFS and plot diameter',async()=>{
 const original=global.document;global.document=fakeDocument();
 try{
  const result=await readBack();assert.equal(result.issue,null);assert(result.map);
  assert.equal(result.map.bfs_radius_mm,6.5);assert.equal(result.map.fit_diameter_mm,8);assert.equal(result.map.diameter_mm,9);
  assert.equal(result.map.elevation_um[20][20].value,-12);assert.equal(result.map.full_display.elevation_um[30][54].value,18);
  assert(result.captions.some(([x,,w])=>Math.abs(x-383)<.01&&w===220),'Back caption is offset from its actual identified circle');
  for(const options of [{caption:'Enhanced BFS (B) Float R=6.50 Dia=8.00'},{caption:'BFS (F) Float R=6.50 Dia=8.00'},{caption:'BFS (B) Float R=6.90 Dia=8.00'},{diameter:'unreadable'},{region:rs=>rs.push({...rs[1]})},{region:rs=>rs[1].cy=.8}]){
   const failed=await readBack(options);assert.equal(failed.map,null);assert(failed.issue);
  }
 }finally{global.document=original;}
});
