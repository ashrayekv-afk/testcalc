'use strict';
const assert=require('node:assert/strict');
const I=require('../components/image_regions.js');
let count=0;
const test=(name,fn)=>{fn();count++;console.log('PASS '+name);};
test('A complete printed two-decimal BFS survives isolated terminal punctuation',()=>{
 assert.equal(I.parseBFSNumber('6.03'),6.03);assert.equal(I.parseBFSNumber('6.03.'),6.03);assert.equal(I.parseBFSNumber(' 5.01 '),5.01);
});
test('Missing digits, invented decimal positions, multiple readings and invalid radii are rejected',()=>{
 for(const text of ['6.0','603','.03','6.03.5','6.03 5.01','6O3','r=6.03','3.00','12.03','-6.03',''])assert.equal(I.parseBFSNumber(text),null,text);
});
test('A standard posterior floating header retains its own reference and fitting diameter',()=>{
 assert.deepEqual(I.parsePosteriorBFSHeader('(B)r=6.45 Float, Dia=8.00'),{radius:6.45,fit_diameter_mm:8});
 assert.deepEqual(I.parsePosteriorBFSHeader('(B))=6.03 Float, Dia=8.00'),{radius:6.03,fit_diameter_mm:8});
 assert.deepEqual(I.parsePosteriorBFSHeader('(B)}=6.03 Float, Dia=8.00'),{radius:6.03,fit_diameter_mm:8});
 assert.deepEqual(I.parsePosteriorBFSHeader('[B)r=6.03 Float, Dia=8.00'),{radius:6.03,fit_diameter_mm:8});
 assert.deepEqual(I.parsePosteriorBFSHeader('(B)=5.01 Float, unreadable'),{radius:5.01,fit_diameter_mm:null});
});
test('Repeated narrow-crop errors cannot overrule a conflicting full-header radius',()=>{
 assert.equal(I.resolveBFSRadius({radius:6.12},[5.12,5.12]),null);
 assert.equal(I.resolveBFSRadius({radius:6.12},[6.12]),6.12);
 assert.equal(I.resolveBFSRadius({radius:null},[6.12,6.12]),null);
});
test('Repeated OCR misreads cannot overwrite a conflicting numeral-shape anchor',()=>{
 assert.equal(I.resolveElevationAnchor(45,[49,5],[49,49]),null);
 assert.equal(I.resolveElevationAnchor(45,[49,45],[49]),45);
 assert.equal(I.resolveElevationAnchor(undefined,[40,40],[]),40);
});
test('Enhanced, difference, anterior and unconfirmed headers cannot replace standard posterior elevation',()=>{
 for(const text of ['(F)r=7.8 Float, Dia=8.00','(B)r=6.45 Excl3mm Float, Dia=8.00','Posterior Difference Float','(B)r=6.45 Enhanced Float','(B)r=6.45 Dia=8.00'])assert.equal(I.parsePosteriorBFSHeader(text),null,text);
});
test('Only accepted signed anchors establish the saved elevation calibration',()=>{
 const p=I.elevationLegendProvenance([{value:-60,y:10},{value:0,y:50},{value:65,y:90}],100);
 assert.deepEqual(p.calibrated_range_um,[-60,65]);assert.deepEqual(p.anchors,[{value:-60,y:.1},{value:0,y:.5},{value:65,y:.9}]);
 assert(!JSON.stringify(p).includes('75'));
});
console.log(`${count} integrated-reader checks passed.`);
